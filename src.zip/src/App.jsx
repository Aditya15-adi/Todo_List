import React, { useState } from "react";
import Todolist from "./Todolist";
import Button from '@material-ui/core/Button';
import Add from '@material-ui/icons/Add';

const App = () => {
    const [ip, setli] = useState();// 'useststate' use to update the value instantaneously and dynamically,'ip' is the variable which stores the current input value
    const [items, setitem] = useState([]);//array created to store the list of item

    const iput = (event) => {//event listener is pass as argument, then with help of this text enetered is fetch
        setli(event.target.value);//setli is used to reassign the value to 'ip' variable
    }
    const listofitem = () => {//this function declared to add the recent item stored in 'ip' variable to the array
        setitem((olditem) => {// setitem is function toi update the array
            return [...olditem, ip]
        })
        setli("");//after clicking on add button it makes the input eull empty or null again

    }
    const deleteitem=(id)=>{
        setitem((olditem) => {
            return olditem.filter((arrit,index)=>{// filter is used to segregate the item that has to be deleted, here we don't include the item in the array which has to be deleted, item deleted with the help of id.
                return id!==index;//index represent the index of item in object it acts as unique identifier for item and id is the id of item to be deleted to be deleted, id is fetched  by passing it as parameter
            })
        })
    }
    return (
        <>
            <div className="container">
                <h2>TO DO LIST</h2>
                <br />
                <input
                    type="text"
                    placeholder="Add a item"
                    onChange={iput}//to store  the value of input in ip variable, iput function is declared
                    value={ip}
                />
                <Button className="sub"onClick={listofitem}><Add/></Button><hr /> 
                <br />
                <ul>
                    
                    {items.map((itemval,index) => {//map is used to displaqy the each item stored in the array
                       return <Todolist 
                            key={index}
                            id={index}// id passed as props to uniquely identify the item
                            text={itemval}// thsi is the actual data
                            onSelect={deleteitem}//function is passed as props

                        />
                    })}
                </ul>
            </div >
        </>
    );
}

export default App;

// listofitem:- function used to add item to array
// ip:- function used to fetch the dynamic data
//useState:- is called as array destructuring variable and function, function is use to set the value of variable, it has two parameters