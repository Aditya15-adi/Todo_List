import React from "react";
import Delete from '@material-ui/icons/DeleteForever'
const Todolist = (props) => {
    return (
        <>
            <div className="list_style">
                <button className="cancel" onClick={()=>{
                    props.onSelect(props.id)//function passed as props is called 
                }}><Delete id="del" /></button>
                <li>{props.text}</li>
            </div>
        </>
    )

}

export default Todolist;